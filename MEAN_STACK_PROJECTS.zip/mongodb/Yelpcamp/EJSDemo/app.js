var express = require("express");
var app = express();

app.use(express.static("public"));
//ROUTES
app.get("/", function(req,res){
    res.render("home.ejs");
    //res.send("WELCOME TO THE HOMEPAGE!");
})

app.get("/love/:girl", function(req,res){
    var girlname = req.params.girl;
   // res.send("You fell in love with "+girlname);
   res.render("love.ejs", {thing : girlname});
})

app.get("/humans", function(req,res){
    var humans = {
          girl :"Ankita",
          boy : "Pratik",
          gay : "Hardik"
        }
    var book = {
         title : "Half Girlfriend",
         author : "Chetan Bhagat"
    };
       
        res.render("human.ejs", {humans : humans});
})


app.listen(process.env.PORT,process.env.IP, function(){
    console.log("Server is listening!");
})