var express = require("express");
var app = express();

app.get("/", function(req,res){
    res.send("Hi There! Welcome to my assignment");
})

app.get("/speak/:animal", function(req,res){
    var sounds={
        pig:"Oink",
        cow:"Moo",
        dog:"WOOF"
    };
    var animal = req.params.animal;
   // var sound=sounds[animal];
    
    res.send("The " + animal + " says " + sounds[animal] );
})

app.get("/:message/:times",function(req,res){
   var message = req.params.message;
   var times = req.params.times;
   var result = "";
   
   for(var i = 0; i < times; i++){
       result = result + message + " ";
   }
   res.send(result);
});

app.listen(process.env.PORT,process.env.IP,function(){
    console.log("Server started!");
});