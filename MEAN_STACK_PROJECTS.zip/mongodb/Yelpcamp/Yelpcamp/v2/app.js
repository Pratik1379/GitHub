var express = require("express");
var app = express();
var bodyParser = require("body-parser");
app.use(bodyParser.urlencoded({ extended: true }));
var mongoose = require("mongoose");
mongoose.Promise = require('bluebird');
mongoose.Promise = global.Promise;
mongoose.connect("mongodb://localhost:27017/yelp_camp", {useNewUrlParser: true, useUnifiedTopology: true});

app.set("view engine", "ejs");
var campgroundSchema = new mongoose.Schema({
	name : String,
	image: String,
	description: String
});

var Campground = mongoose.model("Campground", campgroundSchema);

// Campground.create({
// 	name :  "Pike Place Market",
// 	image: "https://images.unsplash.com/photo-1459058537932-d95b3e068690?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60",
// 	description: "This is a very beautiful market wiht lots of people and useful things!"
// }, function(err, campground){
// 	if(err)
// 		{
// 			console.log(err)
// 		}
// 	else{
// 		console.log("NEWLY CREATED CAMPGROUND!");
// 		console.log(campground);
// 	}
// });


// var places = [
//         {PlaceName: "Brookfield Place", PlaceImage: "https://images.unsplash.com/photo-1440970247296-9a584a45bfcf?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60"},
//         {PlaceName: "Pike Place Market", PlaceImage:"https://images.unsplash.com/photo-1459058537932-d95b3e068690?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60"},
//         {PlaceName: "French Building", PlaceImage:"https://images.unsplash.com/photo-1496277195689-21125faa0eeb?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60 "},
//         {PlaceName: "Brookfield Place", PlaceImage: "https://images.unsplash.com/photo-1440970247296-9a584a45bfcf?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60"},
//         {PlaceName: "Pike Place Market", PlaceImage:"https://images.unsplash.com/photo-1459058537932-d95b3e068690?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60"},
//         {PlaceName: "French Building", PlaceImage:"https://images.unsplash.com/photo-1496277195689-21125faa0eeb?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60 "},
//         {PlaceName: "Brookfield Place", PlaceImage: "https://images.unsplash.com/photo-1440970247296-9a584a45bfcf?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60"},
//         {PlaceName: "Pike Place Market", PlaceImage:"https://images.unsplash.com/photo-1459058537932-d95b3e068690?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60"},
//         {PlaceName: "French Building", PlaceImage:"https://images.unsplash.com/photo-1496277195689-21125faa0eeb?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60 "}
//         ];

app.get("/", function(req, res){
    res.render("landing.ejs");
});

app.get("/campgrounds", function(req, res){
	Campground.find({}, function(err, allCampgrounds){
		if(err){
			console.log(err);
		}else{
			  res.render("campgrounds", {campgrounds : allCampgrounds});
		}
	});
  
});

app.post("/campgrounds", function(req, res){
   var name = req.body.name;
   var image = req.body.image;
	var desc = req.body.description;
   var newCampground = {name : name, image : image, description : desc};
   //Create a new campground and save to DB
	Campground.create( newCampground, function(err, newlyCreated){
		if(err)
			console.log(err);
		else{
			res.redirect("/campgrounds");
		}
	});
});

app.get("/campgrounds/new", function(req,res){
    res.render("new.ejs");
});

app.get("/campgrounds/:id", function(req, res){
	var id = req.params.id;
	Campground.findById(id, function(err, foundCampground){
		if(err){
			console.log(err)
		} else{
			res.render("show", {campground : foundCampground});
		}
	});
	
});

app.listen(process.env.PORT || 4000, process.env.IP, function(){
    console.log("Yelpcamp server has started!!!!");
});