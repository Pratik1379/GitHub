var express = require("express");
var app = express();

app.get("/", function(req,res){
    res.send("Hi There!");
});

app.get("/bye", function(req,res){
    res.send("GoodBye!");
})

app.get("/dog", function(req,res){
    console.log("SOMEONE MADE A REQUEST TO /DOG");
    res.send("MEOW!");
})

app.get("/r/:subredditName", function(req,res){
    var subreddit=req.params.subredditName;
    res.send("Welcome to the " + subreddit +" subreddit!");
})

app.get("*", function(req,res){
    res.send("You are a Star!");
})

app.listen(process.env.PORT,process.env.IP,function(){
    console.log("Server has Started!");
});
