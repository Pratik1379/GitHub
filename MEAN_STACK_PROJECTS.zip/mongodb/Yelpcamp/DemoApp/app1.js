var catme=require("cat-me");
var knock = require("knock-knock-jokes");


console.log(catme());
console.log(knock());


