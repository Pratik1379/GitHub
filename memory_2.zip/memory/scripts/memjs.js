 
var button = document.querySelector("#generate");
var h2 = document.querySelector("h2");
var h5 = document.querySelector("h5");

// var timer=0;
// function startTimer()
// {
//   setInterval("timerUp()",1000);

// };

// function timerUp()
// {
//   timer++;
//         var resetat=6; //change this number to adjust the length of time in seconds
//   if(timer==resetat)
//   {
//     window.location.reload();
//   }
//   var tleft=resetat-timer;
  
  
// };

 // function timeRefresh(timeoutPeriod) {
 //            //h5.textContent = "The page will refresh after 5 seconds..";
 //            setTimeout("location.reload(true);", timeoutPeriod);
 //        };

if(button){
  
button.addEventListener("click", function(){
  var minm = 100000;
  var maxm = 999999;
 var y = Math.floor(Math.random() * (maxm - minm + 1)) + minm;
 var checkString = y.toString();

 var queryString = "?" + checkString;
 h2.textContent = y;

 setTimeout(function(){
    window.location.replace("guess.html" + queryString);
  },5000)
   document.getElementById('timer').innerHTML= "Refreshing the page in 5 seconds..";
});
}


// if(guessButton)
// {
//   guessButton.addEventListener("click", function(){
//   var count = 0;
//   var guessValue = input.value;
//   // console.log(typeof(guessValue));
//   // console.log(typeof(checkString));
//   if(guessValue == "")
//   {
//     alert("Enter a number!");
//   }
//   else
//    {
//      console.log(checkString);
//      countMatch(guessValue);
//    }
//  })
// }


// function countMatch(s1){

//   console.log(checkString);
//   console.log(s1);
//   var count = 0;
//   for(var i = 0; i < s1.length; i++)
//   {
//     if(s1[i] == checkString[i])
//       count++;
//     else
//       break;
//   }
//   console.log(count);
// }

// if(replayButton)
// {
//  replayButton.addEventListener("click", function(){
//   window.location.replace("game.html");
//  })
// }
